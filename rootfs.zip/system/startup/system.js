//!wrt

function deleteAllDataFromIndexedDB(dbName, storeName) {
  // Open the database in readwrite mode
  const request = indexedDB.open(dbName, 1);
  request.onupgradeneeded = function(event) {
    const db = event.target.result; // Get the upgraded database
    if (!db.objectStoreNames.contains(storeName)) {
      const objectStore = db.createObjectStore(storeName);
    }
  };

  request.onsuccess = function(event) {
    const db = event.target.result; // Get the successful database connection
    const transaction = db.transaction([storeName], 'readwrite');
    const objectStore = transaction.objectStore(storeName);

    // Clear all data from the object store
    objectStore.clear().onsuccess = function() {
      console.log('All data deleted from ' + storeName + ' object store');
    };

    // Handle errors
    transaction.onerror = function(event) {
      console.error('Error clearing data:', event.error);
    };
  };

  // Handle connection errors
  request.onerror = function(event) {
    console.error('Error opening database:', event.error);
  };
}

// Example usage:
deleteAllDataFromIndexedDB('W96FS', 'lse');
